/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50725
Source Host           : localhost:3306
Source Database       : mybatis

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2019-07-30 21:43:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL COMMENT '用户名称',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `sex` char(1) DEFAULT NULL COMMENT '性别',
  `address` varchar(256) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'zhang', null, '2', null);
INSERT INTO `user` VALUES ('10', '张三', '2014-07-10', '1', '北京市');
INSERT INTO `user` VALUES ('16', '张小明', null, '1', '河南郑州');
INSERT INTO `user` VALUES ('22', '陈小明', null, '1', '河南郑州');
INSERT INTO `user` VALUES ('24', '张三丰', null, '1', '河南郑州');
INSERT INTO `user` VALUES ('25', '陈小明', null, '1', '河南郑州');
INSERT INTO `user` VALUES ('26', '王五', null, null, null);
INSERT INTO `user` VALUES ('27', '张三', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('29', '张三', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('31', '张三', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('33', '张三', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('34', '张三', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('35', '张三11', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('37', '张三11fdf', null, '男', '广东汕头');
INSERT INTO `user` VALUES ('40', 'zhang', null, '男', null);
INSERT INTO `user` VALUES ('43', 'zhang', null, '男', null);
