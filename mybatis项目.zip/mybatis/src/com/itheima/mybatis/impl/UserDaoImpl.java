package com.itheima.mybatis.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.itheima.mybatis.dao.UserDao;
import com.itheima.mybatis.pojo.User;
import com.itheima.mybatis.utils.SqlSessionFactoryUtils;

public class UserDaoImpl implements UserDao {

	@Override
	public User gUserById(Integer id) {
		
		SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		User user = sqlSession.selectOne("user.getUserById", id);
		sqlSession.close(); //�ر�sqlSession

		return user;
	}

	@Override
	public List<User> getUserByUserName(String userName) {
		
		SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<User> list = sqlSession.selectList("user.getUserByName", userName);
		sqlSession.close();
		return list;
	}

	@Override
	public void insertUser(User user) {
		SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.insert("user.insertUser", user);
		sqlSession.commit();//�ύ����
		sqlSession.close(); 
	}


	@Override
	public void updateUser(User user) {
		SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.insert("user.updateUser", user);
		sqlSession.commit();		
		sqlSession.close();
	}

	@Override
	public void deleteUser(Integer id) {
		SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();
		SqlSession sqlSession = sqlSessionFactory.openSession();
		sqlSession.insert("user.deleteUser", id);
		sqlSession.commit();		
		sqlSession.close();
	}

}
