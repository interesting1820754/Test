package com.itheima.mybatis.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.itheima.mybatis.impl.UserDaoImpl;
import com.itheima.mybatis.pojo.User;

public class UserDaoTest {

	@Test
	public void testGUserById() {
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		User user = userDaoImpl.gUserById(31);
		System.out.println(user);
	}

	@Test
	public void testGetUserByUserName() {
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		List<User> list = userDaoImpl.getUserByUserName("��");
		for(User user:list) {
			System.out.println(user);
		}
	}

	@Test
	public void testInsertUser() {
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		User user = new User();
		user.setUsername("zhang");
		user.setSex("��");
		userDaoImpl.insertUser(user);
		System.out.println(user.getId());
	}
	
	@Test
	public void testupdatetUser() {
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		User user = new User();
		user.setId(1);
		user.setUsername("����");
		userDaoImpl.updateUser(user);
	}
	
	@Test
	public void testdeletetUser() {
		UserDaoImpl userDaoImpl = new UserDaoImpl();
		userDaoImpl.deleteUser(47);
	}

}
