package com.itheima.mybatis.pojo;

import java.util.Date;

public class User {

	private Integer id;//�û�id
	private String userName;// �û���
	private String sex;// �Ա�
	private Date birthday;// ����
	private String address;// ��ַ

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return userName;
	}

	public void setUsername(String username) {
		this.userName = username;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + userName + ", sex=" + sex + ", birthday=" + birthday + ", address="
				+ address + "]";
	}

}
