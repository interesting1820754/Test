
import numpy as py
import operator

#加载数据
def loadData(filePath):
    dataSet=[]
    lable=[]
    with open(filePath) as f:
        for line in f.readlines():
            lines=line.split(",")
            # 获得每一行数据的前4列
            dataSet.append([float(lines[0]),float(lines[1]),float(lines[2]),float(lines[3])])
            lable.append(lines[4])
    return py.array(dataSet),lable

#knn算法
def knn(trainSet,label,testSet,k):
    # 求差的平方和---注意：数组可以做加减，此处均为数组
    distance=(trainSet-testSet)**2
    # 对数组的每一行求和，axis=1为对行求和，axis=0为对每列求和
    distanceLine=distance.sum(axis=1)
    finalDistance=distanceLine**0.5
    # 获得排序后原始下角标
    sortedIndex=finalDistance.argsort()
    # 获得距离最小的前k个下角标
    index=sortedIndex[:k]
    # 字典  key为标签，value为标签出现的次数
    labelCount={}
    for i in index:
        tempLabel=label[i]
        labelCount[tempLabel]=labelCount.get(tempLabel,0)+1
    # operator.itemgetter(1)意思是按照value值排序，即按照欧氏距离排序
    sortedCount=sorted(list(labelCount.items()),key=operator.itemgetter(1),reverse=True)
    return sortedCount[0][0]#输出标签出现最多的那个

#预测正确率
def predict(trainSet,trainLabel,testSet,k):
    total=len(testSet)
    trueCount=0
    for i in range(len(testSet)):
        label=knn(trainSet,trainLabel,testSet[i],k)
        if label in testLabel[i]:
            trueCount=trueCount+1
    return "预测准确率为：{}".format(float(trueCount)/float(total))

if __name__=='__main__':
    trainSet,trainLabel=loadData("./data/iris_train.txt")#训练数据以及标签
    testSet, testLabel = loadData("./data/iris_test.txt")#测试数据以及标签
    print((predict(trainSet,trainLabel,testSet,3)))

